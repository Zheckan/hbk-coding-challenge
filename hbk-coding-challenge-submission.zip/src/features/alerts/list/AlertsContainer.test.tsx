import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { delay, http, HttpResponse } from 'msw'
import { afterEach, describe, expect, it, vi } from 'vitest'

import listFixture from '@/test/fixtures/nws-alert-list.json'
import { renderApp } from '@/test/renderApp'
import { server } from '@/test/server'
import { testIds } from '@/ui/utils/testIds'
import { formatLocalDate } from './logic/local-dates'

const completeFeature = listFixture.features[0]

if (completeFeature === undefined) {
  throw new Error('The alert fixture must contain an alert')
}

describe('alerts list', () => {
  afterEach(() => {
    vi.unstubAllEnvs()
  })

  it('shows a table-shaped skeleton while alerts load', async () => {
    server.use(
      http.get('https://api.weather.gov/alerts', async () => {
        await delay('infinite')

        return HttpResponse.json({})
      }),
    )

    renderApp({ initialEntries: ['/alerts'] })

    const loadingState = await screen.findByRole('status', {
      name: 'Loading weather alerts',
    })
    const loadingTable = within(loadingState).getByRole('table', {
      name: 'Weather alerts loading',
    })

    expect(within(loadingTable).getAllByRole('row').length).toBeGreaterThan(1)
  })

  it('keeps the current alerts visible while filters update', async () => {
    const user = userEvent.setup()
    let finishFilteredRequest: (() => void) | undefined
    const filteredRequest = new Promise<void>((resolve) => {
      finishFilteredRequest = resolve
    })

    server.use(
      http.get('https://api.weather.gov/alerts', async ({ request }) => {
        if (new URL(request.url).searchParams.get('area') === 'KS') {
          await filteredRequest
        }

        return HttpResponse.json(listFixture)
      }),
    )

    renderApp({ initialEntries: ['/alerts'] })

    const table = await screen.findByRole('table', { name: 'Weather alerts' })
    await user.selectOptions(
      screen.getByRole('combobox', { name: 'Area code' }),
      'KS',
    )

    expect(table).toBeVisible()
    expect(within(table).getByText('Flash Flood Warning')).toBeVisible()
    expect(
      screen.getByRole('status', { name: 'Updating weather alerts' }),
    ).toBeVisible()

    finishFilteredRequest?.()
  })

  it('shows a clear message when the loaded results are empty', async () => {
    server.use(
      http.get('https://api.weather.gov/alerts', () =>
        HttpResponse.json({ ...listFixture, features: [], pagination: {} }),
      ),
    )

    renderApp({ initialEntries: ['/alerts'] })

    expect(
      await screen.findByRole('status', { name: 'No weather alerts' }),
    ).toHaveTextContent('No matching alerts in the loaded results.')
    expect(screen.queryByRole('table', { name: 'Weather alerts' })).toBeNull()
  })

  it('can continue loading after the current pages have no search matches', async () => {
    const user = userEvent.setup()
    const nextPageFeature = {
      ...completeFeature,
      id: 'https://api.weather.gov/alerts/coastal-alert',
      properties: {
        ...completeFeature.properties,
        id: 'coastal-alert',
        event: 'Coastal Flood Warning',
      },
    }

    server.use(
      http.get('https://api.weather.gov/alerts', ({ request }) =>
        new URL(request.url).searchParams.get('cursor') === 'next-page-token'
          ? HttpResponse.json({
              ...listFixture,
              features: [nextPageFeature],
              pagination: {},
            })
          : HttpResponse.json(listFixture),
      ),
    )

    renderApp({ initialEntries: ['/alerts?q=coastal'] })

    expect(
      await screen.findByRole('status', { name: 'No weather alerts' }),
    ).toBeVisible()

    await user.click(screen.getByRole('button', { name: 'Load more alerts' }))

    expect(await screen.findByText('Coastal Flood Warning')).toBeVisible()
    expect(
      screen.queryByRole('status', { name: 'Loaded alert count' }),
    ).not.toBeInTheDocument()
  })

  it('explains rate limiting, retries once, and lets the user try again', async () => {
    const user = userEvent.setup()
    let requestCount = 0

    server.use(
      http.get('https://api.weather.gov/alerts', () => {
        requestCount += 1

        if (requestCount <= 2) {
          return HttpResponse.json(
            {
              title: 'Rate limit exceeded',
              status: 429,
              detail: 'Wait before trying this request again.',
            },
            { status: 429 },
          )
        }

        return HttpResponse.json(listFixture)
      }),
    )

    renderApp({ initialEntries: ['/alerts'] })

    expect(
      await screen.findByRole(
        'alert',
        { name: 'NWS rate limit reached' },
        { timeout: 4_000 },
      ),
    ).toHaveTextContent(
      'The National Weather Service is receiving too many requests.',
    )
    expect(requestCount).toBe(2)

    await user.click(screen.getByRole('button', { name: 'Try again' }))

    expect(
      await screen.findByRole('table', { name: 'Weather alerts' }),
    ).toBeVisible()
    expect(requestCount).toBe(3)
  })

  it('does not retry other client errors', async () => {
    let requestCount = 0

    server.use(
      http.get('https://api.weather.gov/alerts', () => {
        requestCount += 1

        return HttpResponse.json(
          {
            title: 'Bad request',
            status: 400,
            detail: 'The request was not accepted.',
          },
          { status: 400 },
        )
      }),
    )

    renderApp({ initialEntries: ['/alerts'] })

    expect(
      await screen.findByRole('alert', {
        name: 'Weather alerts request failed',
      }),
    ).toHaveTextContent('Could not load weather alerts.')
    expect(requestCount).toBe(1)
    expect(
      screen.queryByRole('button', { name: 'Try again' }),
    ).not.toBeInTheDocument()
  })

  it('shows NWS alerts in a semantic table', async () => {
    vi.stubEnv('TZ', 'America/Chicago')
    renderApp({ initialEntries: ['/alerts'] })

    const table = await screen.findByRole('table', {
      name: 'Weather alerts',
    })

    expect(
      within(table)
        .getAllByRole('columnheader')
        .map((heading) => heading.textContent),
    ).toEqual([
      'Severity',
      'Event',
      'Headline',
      'Affected area',
      'Issued',
      'Expires',
      'Details',
    ])

    const alertRow = within(table).getByTestId(
      testIds.alerts.list.row('urn:oid:test.complete'),
    )

    expect(within(alertRow).getByText('Severe')).toBeVisible()
    expect(
      within(alertRow).getByRole('rowheader', {
        name: /Flash Flood Warning/,
      }),
    ).toBeVisible()
    expect(
      within(alertRow).getByText(
        'Flash Flood Warning issued September 14 at 8:29AM CDT',
      ),
    ).toBeVisible()
    expect(
      within(alertRow).getByRole('cell', {
        name: 'Daviess, MO; DeKalb, MO',
      }),
    ).toBeVisible()
    expect(
      within(alertRow).getByRole('cell', {
        name: 'Sep 14, 2026, 8:29 AM CDT',
      }),
    ).toBeVisible()
    expect(
      within(alertRow).getByRole('cell', {
        name: /^Sep 14, 2026, 1:30 PM CDT/,
      }),
    ).toBeVisible()
    expect(
      within(alertRow).getByRole('link', {
        name: 'View details for Flash Flood Warning',
      }),
    ).toHaveAttribute('href', '/alerts/urn%3Aoid%3Atest.complete')
  })

  it('marks alerts whose expiry time has passed', async () => {
    const activeFeature = {
      ...completeFeature,
      id: 'https://api.weather.gov/alerts/active-alert',
      properties: {
        ...completeFeature.properties,
        id: 'active-alert',
        event: 'Winter Storm Watch',
        expires: '2099-01-01T00:00:00+00:00',
      },
    }

    server.use(
      http.get('https://api.weather.gov/alerts', () =>
        HttpResponse.json({
          ...listFixture,
          features: [completeFeature, activeFeature],
        }),
      ),
    )

    renderApp({ initialEntries: ['/alerts'] })

    const table = await screen.findByRole('table', { name: 'Weather alerts' })
    const expiredRow = within(table).getByTestId(
      testIds.alerts.list.row('urn:oid:test.complete'),
    )
    const activeRow = within(table).getByTestId(
      testIds.alerts.list.row('active-alert'),
    )

    expect(
      within(expiredRow).getByRole('cell', { name: /Expired$/ }),
    ).toBeVisible()
    expect(within(activeRow).queryByText('Expired')).not.toBeInTheDocument()
    expect(
      within(activeRow).getByRole('cell', { name: /Active$/ }),
    ).toBeVisible()
  })

  it('lets keyboard users skip the filters and move to the results', async () => {
    const user = userEvent.setup()

    renderApp({ initialEntries: ['/alerts'] })

    await screen.findByRole('link', { name: 'Skip to alert results' })
    await user.tab()

    const skipLink = screen.getByRole('link', {
      name: 'Skip to alert results',
    })
    expect(skipLink).toHaveFocus()

    await user.keyboard('{Enter}')

    expect(
      await screen.findByRole('region', { name: 'Alert results' }),
    ).toHaveFocus()
  })

  it('offers NWS land and marine area codes', async () => {
    renderApp({ initialEntries: ['/alerts'] })

    const areaSelect = await screen.findByRole('combobox', {
      name: 'Area code',
    })

    expect(
      within(areaSelect).getByRole('option', { name: 'KS — Kansas' }),
    ).toBeVisible()
    expect(
      within(areaSelect).getByRole('option', {
        name: 'PZ — Eastern Pacific and U.S. West Coast',
      }),
    ).toBeVisible()
  })

  it('offers only the seven dates available from NWS', async () => {
    renderApp({ initialEntries: ['/alerts'] })

    const issuedFrom = await screen.findByRole('combobox', {
      name: 'Issued from',
    })
    const issuedTo = screen.getByRole('combobox', { name: 'Issued to' })
    const fromValues = within(issuedFrom)
      .getAllByRole('option')
      .map((option) => option.getAttribute('value'))
    const toValues = within(issuedTo)
      .getAllByRole('option')
      .map((option) => option.getAttribute('value'))

    expect(fromValues).toHaveLength(8)
    expect(fromValues[0]).toBe('')
    expect(new Set(fromValues.slice(1)).size).toBe(7)
    expect(toValues).toEqual(fromValues)
  })

  it('restores filters from the URL and sends supported filters to NWS', async () => {
    let requestedUrl: URL | undefined

    server.use(
      http.get('https://api.weather.gov/alerts', ({ request }) => {
        requestedUrl = new URL(request.url)
        return HttpResponse.json(listFixture)
      }),
    )

    renderApp({
      initialEntries: ['/alerts?area=mo&severity=severe&status=actual&q=flood'],
    })

    expect(
      await screen.findByRole('combobox', { name: 'Area code' }),
    ).toHaveValue('MO')
    expect(screen.getByRole('combobox', { name: 'Severity' })).toHaveValue(
      'Severe',
    )
    expect(screen.getByRole('combobox', { name: 'Status' })).toHaveValue(
      'Actual',
    )
    expect(
      screen.getByRole('searchbox', { name: 'Search alerts' }),
    ).toHaveValue('flood')

    expect(requestedUrl?.searchParams.get('area')).toBe('MO')
    expect(requestedUrl?.searchParams.get('severity')).toBe('Severe')
    expect(requestedUrl?.searchParams.get('status')).toBe('actual')
    expect(requestedUrl?.searchParams.has('q')).toBe(false)

    const table = await screen.findByRole('table', { name: 'Weather alerts' })
    expect(
      within(table).getByRole('rowheader', {
        name: /Flash Flood Warning/,
      }),
    ).toBeVisible()
    expect(
      within(table).queryByRole('rowheader', {
        name: /Special Weather Statement/,
      }),
    ).not.toBeInTheDocument()
  })

  it('shows actual alerts by default', async () => {
    let requestedUrl: URL | undefined

    server.use(
      http.get('https://api.weather.gov/alerts', ({ request }) => {
        requestedUrl = new URL(request.url)
        return HttpResponse.json(listFixture)
      }),
    )

    renderApp({ initialEntries: ['/alerts'] })

    expect(await screen.findByRole('combobox', { name: 'Status' })).toHaveValue(
      'Actual',
    )
    await screen.findByRole('table', { name: 'Weather alerts' })
    expect(requestedUrl?.searchParams.get('status')).toBe('actual')
  })

  it('requests every status when the user chooses all statuses', async () => {
    const user = userEvent.setup()
    let requestedUrl: URL | undefined

    server.use(
      http.get('https://api.weather.gov/alerts', ({ request }) => {
        requestedUrl = new URL(request.url)
        return HttpResponse.json(listFixture)
      }),
    )

    const { router } = renderApp({ initialEntries: ['/alerts'] })

    await screen.findByRole('table', { name: 'Weather alerts' })
    await user.selectOptions(
      screen.getByRole('combobox', { name: 'Status' }),
      'All statuses',
    )

    await waitFor(() => {
      expect(router.state.location.search).toBe('?status=all')
    })
    await waitFor(() => {
      expect(requestedUrl?.searchParams.has('status')).toBe(false)
    })
  })

  it('updates the URL when filters and sorting change', async () => {
    const user = userEvent.setup()
    const { router } = renderApp({ initialEntries: ['/alerts'] })

    await screen.findByRole('table', { name: 'Weather alerts' })
    await user.selectOptions(
      screen.getByRole('combobox', { name: 'Area code' }),
      'KS',
    )
    await user.selectOptions(
      screen.getByRole('combobox', { name: 'Severity' }),
      'Moderate',
    )
    await user.type(
      screen.getByRole('searchbox', { name: 'Search alerts' }),
      'lake',
    )

    const table = await screen.findByRole('table', { name: 'Weather alerts' })
    expect(
      within(table).getByRole('columnheader', { name: 'Issued' }),
    ).toHaveAttribute('aria-sort', 'descending')

    await user.click(
      within(table).getByRole('button', { name: 'Sort by severity' }),
    )

    await waitFor(() => {
      expect(router.state.location.search).toBe(
        '?area=KS&severity=moderate&q=lake&sort=severity&direction=asc',
      )
    })
    expect(
      within(table).getByRole('columnheader', { name: 'Severity' }),
    ).toHaveAttribute('aria-sort', 'ascending')
    expect(
      within(table).getByRole('columnheader', { name: 'Issued' }),
    ).not.toHaveAttribute('aria-sort')
  })

  it('offers compact sorting controls for narrow screens', async () => {
    const user = userEvent.setup()
    const { router } = renderApp({ initialEntries: ['/alerts'] })

    await screen.findByRole('table', { name: 'Weather alerts' })
    await user.selectOptions(
      screen.getByRole('combobox', { name: 'Sort alerts by' }),
      'Severity',
    )

    await waitFor(() => {
      expect(router.state.location.search).toBe('?sort=severity&direction=asc')
    })

    await user.click(
      screen.getByRole('button', {
        name: 'Change sort direction to descending',
      }),
    )

    await waitFor(() => {
      expect(router.state.location.search).toBe('?sort=severity')
    })
  })

  it('clears filters without resetting the selected sort', async () => {
    const user = userEvent.setup()
    const { router } = renderApp({
      initialEntries: [
        '/alerts?area=KS&severity=severe&q=flood&sort=severity&page=2',
      ],
    })

    await screen.findByRole('table', { name: 'Weather alerts' })
    await user.click(screen.getByRole('button', { name: 'Clear filters' }))

    await waitFor(() => {
      expect(router.state.location.search).toBe('?sort=severity')
    })
  })

  it('does not request alerts for an invalid date', async () => {
    let requestCount = 0

    server.use(
      http.get('https://api.weather.gov/alerts', () => {
        requestCount += 1
        return HttpResponse.json(listFixture)
      }),
    )

    renderApp({ initialEntries: ['/alerts?from=not-a-date'] })

    expect(await screen.findByRole('alert')).toHaveTextContent(
      'Issued from must be a valid date.',
    )
    expect(requestCount).toBe(0)
  })

  it('explains an invalid date range without sending a request', async () => {
    let requestCount = 0
    const today = new Date()
    const yesterday = new Date(today)
    yesterday.setDate(today.getDate() - 1)

    server.use(
      http.get('https://api.weather.gov/alerts', () => {
        requestCount += 1
        return HttpResponse.json(listFixture)
      }),
    )

    renderApp({
      initialEntries: [
        `/alerts?from=${formatLocalDate(today)}&to=${formatLocalDate(yesterday)}`,
      ],
    })

    expect(await screen.findByRole('alert')).toHaveTextContent(
      'Issued from must be on or before issued to.',
    )
    expect(requestCount).toBe(0)
  })

  it('restores a 25-row page from the URL', async () => {
    const user = userEvent.setup()
    const pagedFixture = {
      ...listFixture,
      features: Array.from({ length: 26 }, (_, index) => {
        const number = String(index + 1).padStart(2, '0')

        return {
          ...completeFeature,
          id: `https://api.weather.gov/alerts/alert-${number}`,
          properties: {
            ...completeFeature.properties,
            id: `alert-${number}`,
            event: `Alert ${number}`,
          },
        }
      }),
    }

    server.use(
      http.get('https://api.weather.gov/alerts', () =>
        HttpResponse.json(pagedFixture),
      ),
    )

    const { router } = renderApp({ initialEntries: ['/alerts?page=2'] })
    const table = await screen.findByRole('table', { name: 'Weather alerts' })

    expect(within(table).getByText('Alert 26')).toBeVisible()
    expect(within(table).queryByText('Alert 01')).not.toBeInTheDocument()

    await user.click(
      within(table).getByRole('button', { name: 'Go to previous page' }),
    )

    await waitFor(() => {
      expect(router.state.location.search).toBe('')
    })
    expect(await within(table).findByText('Alert 01')).toBeVisible()
  })

  it('changes rows per page and opens a page by number', async () => {
    const user = userEvent.setup()
    const pagedFixture = {
      ...listFixture,
      features: Array.from({ length: 26 }, (_, index) => {
        const number = String(index + 1).padStart(2, '0')

        return {
          ...completeFeature,
          id: `https://api.weather.gov/alerts/alert-${number}`,
          properties: {
            ...completeFeature.properties,
            id: `alert-${number}`,
            event: `Alert ${number}`,
          },
        }
      }),
    }

    server.use(
      http.get('https://api.weather.gov/alerts', () =>
        HttpResponse.json(pagedFixture),
      ),
    )

    const { router } = renderApp({ initialEntries: ['/alerts'] })
    const table = await screen.findByRole('table', { name: 'Weather alerts' })

    await user.selectOptions(
      within(table).getByRole('combobox', { name: 'Rows per page' }),
      '10',
    )

    await waitFor(() => {
      expect(router.state.location.search).toBe('?pageSize=10')
    })
    expect(await within(table).findByText('Alert 10')).toBeVisible()
    expect(within(table).queryByText('Alert 11')).not.toBeInTheDocument()

    const pageInput = within(table).getByRole('spinbutton', { name: 'Page' })
    await user.clear(pageInput)
    await user.type(pageInput, '3')

    expect(router.state.location.search).toBe('?pageSize=10')

    await user.keyboard('{Enter}')

    await waitFor(() => {
      expect(router.state.location.search).toBe('?pageSize=10&page=3')
    })
    expect(await within(table).findByText('Alert 21')).toBeVisible()
    expect(within(table).getByText('Alert 26')).toBeVisible()
    expect(within(table).queryByText('Alert 20')).not.toBeInTheDocument()
  })

  it('loads the next NWS page and reports only the alerts already loaded', async () => {
    const user = userEvent.setup()
    let requestedCursor: string | null = null
    const firstPageFeatures = Array.from({ length: 26 }, (_, index) => {
      const number = String(index + 1).padStart(2, '0')

      return {
        ...completeFeature,
        id: `https://api.weather.gov/alerts/alert-${number}`,
        properties: {
          ...completeFeature.properties,
          id: `alert-${number}`,
          event: `Alert ${number}`,
        },
      }
    })
    const nextPageFeature = {
      ...completeFeature,
      id: 'https://api.weather.gov/alerts/next-page-alert',
      properties: {
        ...completeFeature.properties,
        id: 'next-page-alert',
        event: 'Coastal Flood Warning',
      },
    }

    server.use(
      http.get('https://api.weather.gov/alerts', ({ request }) => {
        requestedCursor = new URL(request.url).searchParams.get('cursor')

        if (requestedCursor === 'next-page-token') {
          return HttpResponse.json({
            ...listFixture,
            features: [nextPageFeature],
            pagination: {},
          })
        }

        return HttpResponse.json({
          ...listFixture,
          features: firstPageFeatures,
        })
      }),
    )

    renderApp({ initialEntries: ['/alerts'] })

    expect(await screen.findByText('Alert 01')).toBeVisible()
    expect(screen.getByText('1–25 of 26 loaded, more available')).toBeVisible()
    expect(
      screen.getByRole('button', { name: 'Load more alerts' }),
    ).toBeVisible()

    await user.click(screen.getByRole('button', { name: 'Go to next page' }))

    expect(await screen.findByText('Alert 26')).toBeVisible()

    await user.click(screen.getByRole('button', { name: 'Load more alerts' }))

    expect(requestedCursor).toBe('next-page-token')
    expect(await screen.findByText('Coastal Flood Warning')).toBeVisible()
    expect(screen.getByText('26–27 of 27')).toBeVisible()
    expect(
      screen.queryByRole('button', { name: 'Load more alerts' }),
    ).not.toBeInTheDocument()
  })

  it('keeps loaded alerts visible when the next page fails', async () => {
    const user = userEvent.setup()
    let nextPageRequestCount = 0

    server.use(
      http.get('https://api.weather.gov/alerts', ({ request }) => {
        const cursor = new URL(request.url).searchParams.get('cursor')

        if (cursor !== 'next-page-token') {
          return HttpResponse.json(listFixture)
        }

        nextPageRequestCount += 1

        if (nextPageRequestCount <= 2) {
          return HttpResponse.json(
            { title: 'Service unavailable', status: 503 },
            { status: 503 },
          )
        }

        return HttpResponse.json({
          ...listFixture,
          features: [],
          pagination: {},
        })
      }),
    )

    renderApp({ initialEntries: ['/alerts'] })
    const table = await screen.findByRole('table', { name: 'Weather alerts' })

    await user.click(screen.getByRole('button', { name: 'Load more alerts' }))

    expect(
      await screen.findByRole(
        'alert',
        { name: 'Could not load more alerts' },
        { timeout: 4_000 },
      ),
    ).toHaveTextContent('The alerts above are still available.')
    expect(table).toBeVisible()
    expect(nextPageRequestCount).toBe(2)

    await user.click(screen.getByRole('button', { name: 'Try again' }))

    await waitFor(() => {
      expect(nextPageRequestCount).toBe(3)
    })
    expect(
      screen.queryByRole('alert', { name: 'Could not load more alerts' }),
    ).not.toBeInTheDocument()
  })
})
